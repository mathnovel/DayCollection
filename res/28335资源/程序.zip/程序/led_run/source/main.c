 
#include "DSP2833x_Project.h"
#include <stdio.h>
#include <string.h>


void main(void)
{
    
//	uchar temperkey;

// Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the DSP2833x_SysCtrl.c file.
   
   //ϵͳ��ʼ������
   InitSysCtrl();
   asm(" RPT #8 || NOP");
    
   DINT;
   //GPIO��ʼ������
   InitGpio();
   //PIE��������ʼ������
   InitPieCtrl();

   // ��ֹCPU�жϺ����CU�жϱ�־λ:
   IER = 0x0000;
   IFR = 0x0000;
   
   //��ʼ���ж�����
   InitPieVectTable();
   asm(" RPT #8 || NOP");
  
   while(1)
   { 
  
     configtestledOFF(); //Ϩ��LED�ƣ�I/O����͵�ƽ
	 DELAY_US(500000);   //��ʱ
    
     configtestledON(); //����LED�ƣ�I/O����ߵ�ƽ
     DELAY_US(500000);  //��ʱ

   }
}


void configtestledON(void) //����LED��
{
   EALLOW;
    
   GpioDataRegs.GPASET.bit.GPIO0=1; //LED1
   GpioDataRegs.GPASET.bit.GPIO2=1; //LED2
   GpioDataRegs.GPASET.bit.GPIO4=1; //LED3
   GpioDataRegs.GPASET.bit.GPIO6=1; //LED4
   GpioDataRegs.GPASET.bit.GPIO8=1; //LED5
   GpioDataRegs.GPASET.bit.GPIO10=1;//LED6
   GpioDataRegs.GPASET.bit.GPIO27=1;//LED7
   GpioDataRegs.GPBSET.bit.GPIO52=1;//LED8
   GpioDataRegs.GPASET.bit.GPIO23=1;//RUN

   EDIS;
}

void configtestledOFF(void)
{
   EALLOW;

   GpioDataRegs.GPACLEAR.bit.GPIO0=1;
   GpioDataRegs.GPACLEAR.bit.GPIO2=1;
   GpioDataRegs.GPACLEAR.bit.GPIO4=1;
   GpioDataRegs.GPACLEAR.bit.GPIO6=1;
   GpioDataRegs.GPACLEAR.bit.GPIO8=1;
   GpioDataRegs.GPACLEAR.bit.GPIO10=1;
   GpioDataRegs.GPACLEAR.bit.GPIO27=1;
   GpioDataRegs.GPBCLEAR.bit.GPIO52=1;
   GpioDataRegs.GPACLEAR.bit.GPIO23=1;

   EDIS;
}

void delay (Uint16 t)
{ Uint16 i;
  while(t--)
  {
     for(i=0;i<125;i++)
     asm(" RPT #3 || NOP"); 
  }
}

//




//------------------------------------------------------------------------------------
 
//------------------------------------------------------------------------------------

 

