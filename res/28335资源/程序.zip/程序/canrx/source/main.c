/*********************************************************************
**	Module Name:		CANrx-test  				    			**
**	Author:				CJW  			    						**
**	Version:			1.0			    							**
**	CreateDate:			2009-09-25		    						**
**	Description:		            			    				**
**	Remark:				HELLODSP		    							**
**	Revision History:	2009-10-15			    					**
**      Web:                http://www.hellodsp.com                 **
**********************************************************************/

/*********************************************************************
**	ʵ��Ŀ��:ͨ���ⲿ����CAN�豸��Super2812�������ݣ��˽�CAN���ߵ�  **
**  ���ú�ͨѶ���̣�������ע��ID�����á�                            **
**	ʵ��˵��:��MBOX16����Ϊ����ģʽ���������жϵķ�ʽ��������       **
**	ʵ����:���Թ۲����Rec_h��Rec_l,�����յ�������                **
**********************************************************************/


#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File
void InitECan(void)		// Initialize eCAN-B module
{
   struct ECAN_REGS ECanbShadow;
   EALLOW;		// EALLOW enables access to protected bits
   
  //����GPIO���Ź�����eCAN����
   GpioCtrlRegs.GPAPUD.bit.GPIO16 = 1;   // Disable pull-up for GPIO16 (CANTXB)
   GpioCtrlRegs.GPAPUD.bit.GPIO17 = 0;   // Enable pull-up for GPIO17 (CANRXB)
   GpioCtrlRegs.GPAQSEL2.bit.GPIO17 = 3; // Asynch qual for GPIO17 (CANRXB)
   GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 2;  // Configure GPIO16 for CANTXB operation
   GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 2;  // Configure GPIO17 for CANRXB operation
  
  //����eCAN��RX��TX�ֱ�ΪeCAN�Ľ��պͷ�������
    ECanbShadow.CANTIOC.all = ECanbRegs.CANTIOC.all;
    ECanbShadow.CANTIOC.bit.TXFUNC = 1;
    ECanbRegs.CANTIOC.all = ECanbShadow.CANTIOC.all;

    ECanbShadow.CANRIOC.all = ECanbRegs.CANRIOC.all;
    ECanbShadow.CANRIOC.bit.RXFUNC = 1;
    ECanbRegs.CANRIOC.all = ECanbShadow.CANRIOC.all;

	ECanbShadow.CANMC.all = ECanbRegs.CANMC.all;
	ECanbShadow.CANMC.bit.STM = 0;				//����������ģʽ
	ECanbShadow.CANMC.bit.SCB = 1;
	ECanbRegs.CANMC.all = ECanbShadow.CANMC.all;
   //��ʼ���������豸��������Ϊ0��MCF���е�λ����ʼ��Ϊ0 
    ECanbMboxes.MBOX0.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX1.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX2.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX3.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX4.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX5.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX6.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX7.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX8.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX9.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX10.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX11.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX12.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX13.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX14.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX15.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX16.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX17.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX18.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX19.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX20.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX21.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX22.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX23.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX24.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX25.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX26.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX27.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX28.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX29.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX30.MSGCTRL.all = 0x00000000;
    ECanbMboxes.MBOX31.MSGCTRL.all = 0x00000000;

// TAn, RMPn, GIFn bits are all zero upon reset and are cleared again
//	as a matter of precaution.

    ECanbShadow.CANTA.all = ECanbRegs.CANTA.all;
    ECanbShadow.CANTA.all = 0xFFFFFFFF;
    ECanbRegs.CANTA.all = ECanbShadow.CANTA.all;

	ECanbShadow.CANRMP.all = ECanbRegs.CANRMP.all;
    ECanbShadow.CANRMP.all = 0xFFFFFFFF;
    ECanbRegs.CANRMP.all = ECanbShadow.CANRMP.all;


    ECanbShadow.CANGIF0.all = ECanbRegs.CANGIF0.all;
    ECanbShadow.CANGIF0.all = 0xFFFFFFFF;
    ECanbRegs.CANGIF0.all = ECanbShadow.CANGIF0.all;

    ECanbShadow.CANGIF1.all = ECanbRegs.CANGIF1.all;
    ECanbShadow.CANGIF1.all = 0xFFFFFFFF;
    ECanbRegs.CANGIF1.all = ECanbShadow.CANGIF1.all;

/* Configure bit timing parameters for eCANB*/

	ECanbShadow.CANMC.all = ECanbRegs.CANMC.all;
	ECanbShadow.CANMC.bit.CCR = 1 ;            // Set CCR = 1
    ECanbRegs.CANMC.all = ECanbShadow.CANMC.all;

    do
	{
	    ECanbShadow.CANES.all = ECanbRegs.CANES.all;
	} while(ECanbShadow.CANES.bit.CCE != 1 ); 		// Wait for CCE bit to be  cleared..


    ECanbShadow.CANBTC.all = ECanbRegs.CANBTC.all;
    ECanbShadow.CANBTC.bit.BRPREG = 9;//������500K
	/*150/10=15*/
    ECanbShadow.CANBTC.bit.TSEG2REG = 2;
    ECanbShadow.CANBTC.bit.TSEG1REG = 10;  
    ECanbRegs.CANBTC.all = ECanbShadow.CANBTC.all;

    ECanbShadow.CANMC.all = ECanbRegs.CANMC.all;
	ECanbShadow.CANMC.bit.CCR = 0 ;            // Set CCR = 0
    ECanbRegs.CANMC.all = ECanbShadow.CANMC.all;
	
    do
    {
      ECanbShadow.CANES.all = ECanbRegs.CANES.all;
    } while(ECanbShadow.CANES.bit.CCE != 0 ); 		// Wait for CCE bit to be  cleared..


	ECanbShadow.CANME.all = ECanbRegs.CANME.all;
 	ECanbShadow.CANME.all = 0;		// Required before writing the MSGIDs 
    ECanbRegs.CANME.all = ECanbShadow.CANME.all;
	
	/*���������ID��*/
	ECanbMboxes.MBOX16.MSGID.all =  0x80C20000;
    
	/*����0ΪTX��16ΪRX*/
	ECanbShadow.CANMD.all = ECanbRegs.CANMD.all;
    ECanbShadow.CANMD.bit.MD16 =1;
	ECanbRegs.CANMD.all = ECanbShadow.CANMD.all;
	
	/*���ݳ��� 8��BYTE*/
	ECanbMboxes.MBOX16.MSGCTRL.bit.DLC = 8;
	
	//���÷������ȼ�  2009.3.15 Add
	//ECanbMboxes.MBOX16.MSGCTRL.bit.TPL = 0;
	
	/*û��Զ��Ӧ��֡������*/
	ECanbMboxes.MBOX16.MSGCTRL.bit.RTR = 0;
	
   //������RAM��д����
	//ECanbMboxes.MBOX0.MDH.all = 0x89ABCDEF;
	
	//����ʹ��Mailbox0
	ECanbShadow.CANME.all = ECanbRegs.CANME.all;
	ECanbShadow.CANME.bit.ME16 =1;
	ECanbRegs.CANME.all = ECanbShadow.CANME.all;
	
	ECanbRegs.CANMIM.all = 0xFFFFFFFF;
    //�����жϽ�������ECAN0INT
    ECanbRegs.CANMIL.all = 0;
    ECanbRegs.CANGIF0.all = 0xFFFFFFFF;
    //ECAN0INT�ж������߱�ʹ��
    ECanbRegs.CANGIM.bit.I0EN = 1;
	
    EDIS;
}


void main(void)
{
	InitSysCtrl();
	DINT;
	IER = 0x0000;
	IFR = 0x0000;
	InitPieCtrl();
	InitPieVectTable();	
    InitECan();
	
    //ʹ��PIE�ж�   
	PieCtrlRegs.PIEIER9.bit.INTx7 = 1;
	
	//ʹ��CPU�ж�
	IER |= M_INT9;
	
	EINT;   //��ȫ���ж�
	ERTM;	//��ʵʱ�ж�
	for(;;)
	{
		
	}
 	
}

//===========================================================================
// No more.
//===========================================================================
