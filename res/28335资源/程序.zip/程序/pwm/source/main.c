 
#include "DSP2833x_Project.h"
#include <stdio.h>
#include <string.h>

#define DELAY 35.700L
#if (CPU_FRQ_150MHZ)
  #define CPU_CLK   150e6
#endif
#if (CPU_FRQ_100MHZ)
  #define CPU_CLK   100e6
#endif
#define PWM_CLK   10e3                // If diff freq. desired, change freq here.
#define SP        CPU_CLK/(2*PWM_CLK)
#define TBCTLVAL  0x200E              // Up-down cnt, timebase = SYSCLKOUT


void StartEPwm(void);
	 
Uint32 LoopCount;

void main(void)
{

// Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the DSP2833x_SysCtrl.c file.
   InitSysCtrl();
   asm(" RPT #8 || NOP");
   DINT;
 
   InitPieCtrl();
   DINT;

// Disable CPU interrupts and clear all CPU interrupt flags:
   IER = 0x0000;
   IFR = 0x0000;
   InitPieVectTable();
   asm(" RPT #8 || NOP");
   DINT;
   
   EALLOW;	// This is needed to write to EALLOW protected registers
  
   InitEPwm1Gpio();
   InitEPwm2Gpio();
   InitEPwm3Gpio();
   InitEPwm4Gpio();
   InitEPwm5Gpio();
   InitEPwm6Gpio();
  
   EDIS;
   DINT;  

   StartEPwm();

   
  while(1)
  { 
  
  }
}



//------------------------------------------------------------------------------------
void StartEPwm()
{  
    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
   	EPwm1Regs.TBSTS.all=0;
	EPwm1Regs.TBPHS.half.TBPHS=0;
	EPwm1Regs.TBCTR=0;

	EPwm1Regs.CMPCTL.all=0x50;        // Immediate mode for CMPA and CMPB
	EPwm1Regs.CMPA.half.CMPA =SP/2;
	EPwm1Regs.CMPB=0;

	EPwm1Regs.AQCTLA.all=0x60;        // EPWMxA = 1 when CTR=CMPA and counter inc
	                                  // EPWMxA = 0 when CTR=CMPA and counter dec
	EPwm1Regs.AQCTLB.all=0;
	EPwm1Regs.AQSFRC.all=0;
	EPwm1Regs.AQCSFRC.all=0;

	EPwm1Regs.DBCTL.all=0xb;          // EPWMxB is inverted
	EPwm1Regs.DBRED=0;
	EPwm1Regs.DBFED=0;

	EPwm1Regs.TZSEL.all=0;
	EPwm1Regs.TZCTL.all=0;
	EPwm1Regs.TZEINT.all=0;
	EPwm1Regs.TZFLG.all=0;
	EPwm1Regs.TZCLR.all=0;
	EPwm1Regs.TZFRC.all=0;

	EPwm1Regs.ETSEL.all=0;            // Interrupt when TBCTR = 0x0000
	EPwm1Regs.ETFLG.all=0;
	EPwm1Regs.ETCLR.all=0;
	EPwm1Regs.ETFRC.all=0;

	EPwm1Regs.PCCTL.all=0;

	EPwm1Regs.TBCTL.all=0x0010+TBCTLVAL;			// Enable Timer
	EPwm1Regs.TBPRD=SP;
	
	
	
	EPwm2Regs.TBSTS.all=0;
	EPwm2Regs.TBPHS.half.TBPHS=0;
	EPwm2Regs.TBCTR=0;

	EPwm2Regs.CMPCTL.all=0x50;        // Immediate mode for CMPA and CMPB
	EPwm2Regs.CMPA.half.CMPA =SP/2;
	EPwm2Regs.CMPB=0;

	EPwm2Regs.AQCTLA.all=0x60;        // EPWMxA = 1 when CTR=CMPA and counter inc
	                                  // EPWMxA = 0 when CTR=CMPA and counter dec
	EPwm2Regs.AQCTLB.all=0;
	EPwm2Regs.AQSFRC.all=0;
	EPwm2Regs.AQCSFRC.all=0;

	EPwm2Regs.DBCTL.all=0xb;          // EPWMxB is inverted
	EPwm2Regs.DBRED=0;
	EPwm2Regs.DBFED=0;

	EPwm2Regs.TZSEL.all=0;
	EPwm2Regs.TZCTL.all=0;
	EPwm2Regs.TZEINT.all=0;
	EPwm2Regs.TZFLG.all=0;
	EPwm2Regs.TZCLR.all=0;
	EPwm2Regs.TZFRC.all=0;

	EPwm2Regs.ETSEL.all=0;            // Interrupt when TBCTR = 0x0000
	EPwm2Regs.ETFLG.all=0;
	EPwm2Regs.ETCLR.all=0;
	EPwm2Regs.ETFRC.all=0;

	EPwm2Regs.PCCTL.all=0;

	EPwm2Regs.TBCTL.all=0x0010+TBCTLVAL;			// Enable Timer
	EPwm2Regs.TBPRD=SP;



	EPwm3Regs.TBSTS.all=0;
	EPwm3Regs.TBPHS.half.TBPHS=0;
	EPwm3Regs.TBCTR=0;

	EPwm3Regs.CMPCTL.all=0x50;        // Immediate mode for CMPA and CMPB
	EPwm3Regs.CMPA.half.CMPA =SP/2;
	EPwm3Regs.CMPB=0;

	EPwm3Regs.AQCTLA.all=0x60;        // EPWMxA = 1 when CTR=CMPA and counter inc
	                                  // EPWMxA = 0 when CTR=CMPA and counter dec
	EPwm3Regs.AQCTLB.all=0;
	EPwm3Regs.AQSFRC.all=0;
	EPwm3Regs.AQCSFRC.all=0;

	EPwm3Regs.DBCTL.all=0xb;          // EPWMxB is inverted
	EPwm3Regs.DBRED=0;
	EPwm3Regs.DBFED=0;

	EPwm3Regs.TZSEL.all=0;
	EPwm3Regs.TZCTL.all=0;
	EPwm3Regs.TZEINT.all=0;
	EPwm3Regs.TZFLG.all=0;
	EPwm3Regs.TZCLR.all=0;
	EPwm3Regs.TZFRC.all=0;

	EPwm3Regs.ETSEL.all=0;            // Interrupt when TBCTR = 0x0000
	EPwm3Regs.ETFLG.all=0;
	EPwm3Regs.ETCLR.all=0;
	EPwm3Regs.ETFRC.all=0;

	EPwm3Regs.PCCTL.all=0;

	EPwm3Regs.TBCTL.all=0x0010+TBCTLVAL;			// Enable Timer
	EPwm3Regs.TBPRD=SP;



	EPwm4Regs.TBSTS.all=0;
	EPwm4Regs.TBPHS.half.TBPHS=0;
	EPwm4Regs.TBCTR=0;

	EPwm4Regs.CMPCTL.all=0x50;        // Immediate mode for CMPA and CMPB
	EPwm4Regs.CMPA.half.CMPA =SP/2;
	EPwm4Regs.CMPB=0;

	EPwm4Regs.AQCTLA.all=0x60;        // EPWMxA = 1 when CTR=CMPA and counter inc
	                                  // EPWMxA = 0 when CTR=CMPA and counter dec
	EPwm4Regs.AQCTLB.all=0;
	EPwm4Regs.AQSFRC.all=0;
	EPwm4Regs.AQCSFRC.all=0;

	EPwm4Regs.DBCTL.all=0xb;          // EPWMxB is inverted
	EPwm4Regs.DBRED=0;
	EPwm4Regs.DBFED=0;

	EPwm4Regs.TZSEL.all=0;
	EPwm4Regs.TZCTL.all=0;
	EPwm4Regs.TZEINT.all=0;
	EPwm4Regs.TZFLG.all=0;
	EPwm4Regs.TZCLR.all=0;
	EPwm4Regs.TZFRC.all=0;

	EPwm4Regs.ETSEL.all=0;            // Interrupt when TBCTR = 0x0000
	EPwm4Regs.ETFLG.all=0;
	EPwm4Regs.ETCLR.all=0;
	EPwm4Regs.ETFRC.all=0;

	EPwm4Regs.PCCTL.all=0;

	EPwm4Regs.TBCTL.all=0x0010+TBCTLVAL;			// Enable Timer
	EPwm4Regs.TBPRD=SP;



	EPwm5Regs.TBSTS.all=0;
	EPwm5Regs.TBPHS.half.TBPHS=0;
	EPwm5Regs.TBCTR=0;

	EPwm5Regs.CMPCTL.all=0x50;        // Immediate mode for CMPA and CMPB
	EPwm5Regs.CMPA.half.CMPA =SP/2;
	EPwm5Regs.CMPB=0;

	EPwm5Regs.AQCTLA.all=0x60;        // EPWMxA = 1 when CTR=CMPA and counter inc
	                                  // EPWMxA = 0 when CTR=CMPA and counter dec
	EPwm5Regs.AQCTLB.all=0;
	EPwm5Regs.AQSFRC.all=0;
	EPwm5Regs.AQCSFRC.all=0;

	EPwm5Regs.DBCTL.all=0xb;          // EPWMxB is inverted
	EPwm5Regs.DBRED=0;
	EPwm5Regs.DBFED=0;

	EPwm5Regs.TZSEL.all=0;
	EPwm5Regs.TZCTL.all=0;
	EPwm5Regs.TZEINT.all=0;
	EPwm5Regs.TZFLG.all=0;
	EPwm5Regs.TZCLR.all=0;
	EPwm5Regs.TZFRC.all=0;

	EPwm5Regs.ETSEL.all=0;            // Interrupt when TBCTR = 0x0000
	EPwm5Regs.ETFLG.all=0;
	EPwm5Regs.ETCLR.all=0;
	EPwm5Regs.ETFRC.all=0;

	EPwm5Regs.PCCTL.all=0;

	EPwm5Regs.TBCTL.all=0x0010+TBCTLVAL;			// Enable Timer
	EPwm5Regs.TBPRD=SP;




	EPwm6Regs.TBSTS.all=0;
	EPwm6Regs.TBPHS.half.TBPHS=0;
	EPwm6Regs.TBCTR=0;

	EPwm6Regs.CMPCTL.all=0x50;        // Immediate mode for CMPA and CMPB
	EPwm6Regs.CMPA.half.CMPA =SP/2;
	EPwm6Regs.CMPB=0;

	EPwm6Regs.AQCTLA.all=0x60;        // EPWMxA = 1 when CTR=CMPA and counter inc
	                                  // EPWMxA = 0 when CTR=CMPA and counter dec
	EPwm6Regs.AQCTLB.all=0;
	EPwm6Regs.AQSFRC.all=0;
	EPwm6Regs.AQCSFRC.all=0;

	EPwm6Regs.DBCTL.all=0xb;          // EPWMxB is inverted
	EPwm6Regs.DBRED=0;
	EPwm6Regs.DBFED=0;

	EPwm6Regs.TZSEL.all=0;
	EPwm6Regs.TZCTL.all=0;
	EPwm6Regs.TZEINT.all=0;
	EPwm6Regs.TZFLG.all=0;
	EPwm6Regs.TZCLR.all=0;
	EPwm6Regs.TZFRC.all=0;

	EPwm6Regs.ETSEL.all=0;            // Interrupt when TBCTR = 0x0000
	EPwm6Regs.ETFLG.all=0;
	EPwm6Regs.ETCLR.all=0;
	EPwm6Regs.ETFRC.all=0;

	EPwm6Regs.PCCTL.all=0;

	EPwm6Regs.TBCTL.all=0x0010+TBCTLVAL;			// Enable Timer
	EPwm6Regs.TBPRD=SP;

    SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;
	 EDIS;
}
 
//------------------------------------------------------------------------------------

 

