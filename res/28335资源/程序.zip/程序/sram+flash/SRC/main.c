 
#include "DSP2833x_Project.h"
#include <stdio.h>
#include <string.h>

#define DELAY 35.700L

#define		TimeOutErr				 1
#define		VerifyErr				 2
#define		WriteOK					 0
#define		EraseErr				 3
#define		EraseOK					 0			
#define		SectorSize				 0x800
#define		BlockSize				 0x8000
 Uint16  *FlashStart = (Uint16 *)0x200000;//��չflash���׵�ַ
 Uint16  *ExRamStart = (Uint16 *)0x280000; //��չsram���׵�ַ 


 void SectorErase(void); //���β�������

 void ChipErase(void);   //Ƭ��������
 void FlashWrite(void);  //FLASHд����
 void FlashRead( void ); //FLASH������
 void InitExRam(void);   //����RAM��ʼ������

 void RamRead(void); //����RAM������



 Uint16 RamBuffer[0x10];	 


void main(void)
{
    

   InitSysCtrl(); //ϵͳ��ʼ��
   asm(" RPT #8 || NOP");
   DINT; //��ֹ�ж�
   InitGpio(); //��ʼ��GPIO


   InitXintf(); //��ʼ���ⲿ��չ�ӿ�
   DINT;

   InitPieCtrl(); //��ʼ��PIE������
   DINT;
   
   InitFlash(); //��ʼ��FALSH
// Disable CPU interrupts and clear all CPU interrupt flags:
   IER = 0x0000; //��ֹCPU�ж�
   IFR = 0x0000; //���CPU�жϱ�־λ
   InitPieVectTable(); //��ʼ��PIE�ж�������
   asm(" RPT #8 || NOP");


   //test SRAM AND FLASH
   ChipErase();
   DELAY_US(500);
   SectorErase();
   DELAY_US(500);
   
   InitExRam();
   DELAY_US(500);
   
   FlashWrite(); 
   DELAY_US(500);
    
   DINT;
   asm(" RPT #5 || NOP");
   EINT;

   
while(1)
{ 
   
  
     configtestledOFF();
	 DELAY_US(50000);
    
  
     DELAY_US(500);
     configtestledON();
     DINT;
	 DELAY_US(50);
	 EINT;
     DELAY_US(50000);

  }
}


void configtestledON(void)
{
   EALLOW;
    SYSRUN_SET = 1;
   EDIS;
}

void configtestledOFF(void)
{
   EALLOW;
    SYSRUN_CLEAR = 1;
   EDIS;
}
void delay (Uint16 t)
{ Uint16 i;
  while(t--)
  {
     for(i=0;i<125;i++)
      asm(" RPT #3 || NOP"); 
  }
}

void InitExRam(void) //����RAM��ʼ����������RAM�ռ�д����
 {
	Uint16	i;

    for(i=0;i < 0xffff;i++)
    { 
			*(ExRamStart + i) = i;
	}
 			
 }
 
void RamRead(void)
 {
			Uint16	i;
   for(i=0;i < 0x10;i++)
    { 
			RamBuffer[i] =	*(ExRamStart + i) ;
	}	 
 }	
 //----------------------------------FLASH TEST------------------------
void SectorErase(void)
		{   
			*(FlashStart + 0x5555) = 0xAAAA;
			*(FlashStart + 0x2AAA) = 0x5555;
			*(FlashStart + 0x5555) = 0x8080;
			*(FlashStart + 0x5555) = 0xAAAA;
			*(FlashStart + 0x2AAA) = 0x5555;
			*(FlashStart + SectorSize*4) = 0x3030;
			DINT;
		    DELAY_US(40000);
			EINT;
		    											
		}
		
 void FlashWrite(void)
		{
			Uint16 i;
           	for	(i=0;i< 0x800;i++)
				{
					*(FlashStart + 0x5555) = 0x00AA;
					*(FlashStart + 0x2AAA) = 0x0055;
					*(FlashStart + 0x5555) = 0x00A0;
					*(FlashStart+i)=i;
					DINT;
                     DELAY_US(50);
					 EINT;
				}						

		}

 void FlashRead(void)
	{
			Uint16	i;
			Uint16	Temp;
			for	(i=0;i< 0x10;i++)
				{
				Temp =  *(FlashStart +i);
		        *(ExRamStart+i) = Temp;
				}	
	}	
	void	ChipErase(void)
{

	*(FlashStart + 0x5555) = 0xAAAA;
	*(FlashStart + 0x2AAA) = 0x5555;
	*(FlashStart + 0x5555) = 0x8080;
	*(FlashStart + 0x5555) = 0xAAAA;
	*(FlashStart + 0x2AAA) = 0x5555;
	*(FlashStart + 0x5555) = 0x1010;	
}					
//------------------------------------------------------------------------------------

 

