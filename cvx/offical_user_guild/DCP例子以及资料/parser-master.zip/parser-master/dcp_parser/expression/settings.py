""" Constants for expression module. """

# Constants for computing priority.
MULT = '*'
DIV = '/'
PLUS = '+'
MINUS = '-'
PRIORITY_MAP = {MULT: 2, DIV: 2, PLUS: 1, MINUS: 1}

# Constants for 