""" Constants for error_messages module. """
DCP_ERROR_MSG = "Disciplined convex programming violation:\n"