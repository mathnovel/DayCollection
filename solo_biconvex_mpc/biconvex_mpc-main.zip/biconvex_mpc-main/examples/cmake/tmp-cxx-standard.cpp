#include <iostream>
int main(){std::cout << __cplusplus;return 0;}
